class PositionData {
  PositionData(this.position, this.bufferedposition, this.duration);
  final Duration position;
  final Duration bufferedposition;
  final Duration duration;
}
