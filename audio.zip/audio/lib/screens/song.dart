import 'package:audio/models/controls.dart';
import 'package:audio/models/metadata.dart';
import 'package:audio/models/position.dart';
import 'package:audio/screens/audio_list.dart';
import 'package:audio_video_progress_bar/audio_video_progress_bar.dart';
import 'package:flutter/material.dart';
import 'package:just_audio/just_audio.dart';
import 'package:just_audio_background/just_audio_background.dart';
import 'package:on_audio_query/on_audio_query.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:rxdart/rxdart.dart';

class SongPlayer extends StatefulWidget {
  final List<MediaItem> songs;
  final int initialIndex;

  SongPlayer({required this.songs, this.initialIndex = 0});
  @override
  State<SongPlayer> createState() => _SongPlayerState();
}

class _SongPlayerState extends State<SongPlayer> {
  late AudioPlayer _audioPlayer;

  late ConcatenatingAudioSource _playlist;

  Future<void> _fetchSongs1() async {
    final permissionStatus = await Permission.storage.request();
    if (permissionStatus.isGranted) {
      final songsResult = await OnAudioQuery().querySongs();
      final audioSources = <AudioSource>[];

      for (final song in songsResult) {
        final uri = Uri.parse(song.uri ?? '');

        audioSources.add(
          AudioSource.uri(
            uri,
            tag: MediaItem(
              id: song.id.toString(),
              title: song.title,
              artist: song.artist,
              album: song.album,
            ),
          ),
        );
      }
      _playlist.addAll(audioSources);
    } else {
      print('Permission denied');
    }
  }

  Stream<PositionData> get _positionDataStream {
    return Rx.combineLatest3<Duration, Duration, Duration?, PositionData>(
        _audioPlayer.positionStream,
        _audioPlayer.bufferedPositionStream,
        _audioPlayer.durationStream,
        (position, bufferedposition, duration) => PositionData(
            position, bufferedposition, duration ?? Duration.zero));
  }

  @override
  void initState() {
    super.initState();
    _audioPlayer = AudioPlayer();
    _playlist = ConcatenatingAudioSource(
        children: widget.songs.map((song) {
      return AudioSource.uri(
        song.artUri!,
        tag: song,
      );
    }).toList());
    _fetchSongs1().then((value) => _init());
  }

  Future<void> _init() async {
    await _audioPlayer.setLoopMode(LoopMode.all);
    await _audioPlayer.setAudioSource(_playlist);
    await _audioPlayer.setAudioSource(
      _playlist,
      initialIndex: widget.initialIndex,
    );
  }

  @override
  void dispose() {
    _audioPlayer.dispose();
    super.dispose();
  }

  Widget build(BuildContext context) {
    var _selectedIndex = 0;
    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        leading: const BackButton(
          color: Colors.white,
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.only(top: 40.0),
        child: Container(
          padding: const EdgeInsets.all(20),
          height: double.infinity,
          width: double.infinity,
          decoration: const BoxDecoration(
            gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [
                  Color.fromARGB(255, 145, 6, 99),
                  Color.fromRGBO(198, 127, 5, 0.522),
                ]),
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              StreamBuilder(
                  stream: _audioPlayer.sequenceStateStream,
                  builder: (context, snapshot) {
                    final state = snapshot.data;
                    if (state?.sequence.isEmpty ?? true) {
                      return const SizedBox();
                    }
                    final metadta = state!.currentSource!.tag as MediaItem;
                    return MediaMetadata(
                        imageUrl:
                            'https://img.freepik.com/free-photo/texture-treble-clef-dark-background-isolated-generative-ai_169016-29581.jpg?size=626&ext=jpg&ga=GA1.1.735520172.1710547200&semt=sph',
                        artist: metadta.title);
                  }),
              const SizedBox(
                height: 20,
              ),
              StreamBuilder(
                  stream: _positionDataStream,
                  builder: (context, snapshot) {
                    final positiondata = snapshot.data;
                    return ProgressBar(
                      barHeight: 8,
                      baseBarColor: Colors.grey[800],
                      bufferedBarColor: Colors.grey,
                      progressBarColor: Colors.red,
                      thumbColor: Colors.red,
                      timeLabelTextStyle: const TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                      ),
                      progress: positiondata?.position ?? Duration.zero,
                      buffered: positiondata?.bufferedposition ?? Duration.zero,
                      total: positiondata?.duration ?? Duration.zero,
                      onSeek: _audioPlayer.seek,
                    );
                  }),
              Controls(audioPlayer: _audioPlayer),
            ],
          ),
        ),
      ),
      bottomNavigationBar: BottomNavigationBar(
          items: <BottomNavigationBarItem>[
            BottomNavigationBarItem(
              icon: IconButton(
                onPressed: () {
                  Navigator.of(context).push(
                      MaterialPageRoute(builder: (context) => SongsPage()));
                },
                icon: const Icon(
                  Icons.file_copy_sharp,
                ),
              ),
              label: 'Home',
            ),
            const BottomNavigationBarItem(
              icon: Icon(Icons.favorite),
              label: 'Favourite',
            ),
            const BottomNavigationBarItem(
              icon: Icon(Icons.settings),
              label: 'Setting',
            ),
          ],
          currentIndex: _selectedIndex,
          selectedItemColor: const Color.fromARGB(255, 145, 6, 99),
          onTap: (value) {
            setState(() {
              _selectedIndex = value;
            });
          }),
    );
  }
}
