import 'package:audio/screens/audio_list.dart';
import 'package:flutter/material.dart';

class mytab extends StatefulWidget {
  const mytab({super.key});

  @override
  State<mytab> createState() => _mytabState();
}

// ignore: camel_case_types
class _mytabState extends State<mytab> {
  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 5,
      child: Scaffold(
        appBar: AppBar(
          backgroundColor: const Color.fromARGB(255, 145, 6, 99),
          title: const Text(
            'Audio Player',
            style: TextStyle(color: Colors.white),
          ),
          bottom: const TabBar(
              indicatorColor: Colors.white,
              labelColor: Colors.white,
              tabs: [
                Tab(
                  text: 'Songs',
                ),
                Tab(text: 'PlayList'),
                Tab(text: 'Albums'),
                Tab(text: 'Artist'),
                Tab(text: 'Folders'),
              ]),
        ),
        body: TabBarView(
          children: [
            SongsPage(),
            const Center(child: Text('Your Playlist')),
            const Center(child: Text('Albums')),
            const Center(child: Text('Artists')),
            const Center(child: Text('Folders')),
          ],
        ),
      ),
    );
  }
}
