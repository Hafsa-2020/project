import 'package:audio/screens/song.dart';
import 'package:flutter/material.dart';
import 'package:just_audio/just_audio.dart';
import 'package:just_audio_background/just_audio_background.dart';
import 'package:on_audio_query/on_audio_query.dart';
import 'package:permission_handler/permission_handler.dart';

class SongsPage extends StatefulWidget {
  @override
  _SongsPageState createState() => _SongsPageState();
}

class _SongsPageState extends State<SongsPage> {
  final ConcatenatingAudioSource _playlist =
      ConcatenatingAudioSource(children: []);
  final List<MediaItem> _mediaItems = [];
  @override
  void initState() {
    super.initState();
    _fetchSongs();
  }

  Future<void> _fetchSongs() async {
    final permissionStatus = await Permission.storage.request();
    if (permissionStatus.isGranted) {
      final List<SongModel> songsResult = await OnAudioQuery().querySongs();

      // Sort the songs alphabetically by title
      songsResult.sort((a, b) => (a.title ?? '').compareTo(b.title ?? ''));

      final List<MediaItem> mediaItems = songsResult.map((song) {
        return MediaItem(
          id: song.id.toString(),
          title: song.title ?? 'Unknown Title',
          artist: song.artist ?? 'Unknown Artist',
          album: song.album ?? 'Unknown Album',
          duration: Duration(milliseconds: song.duration ?? 0),
          artUri: song.uri != null ? Uri.parse(song.uri!) : null,
        );
      }).toList();
      setState(() {
        _mediaItems.addAll(mediaItems);
      });
    } else {
      print('Permission denied');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: ListView.builder(
        itemCount: _mediaItems.length,
        itemBuilder: (context, index) {
          final song = _mediaItems[index];
          return InkWell(
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => SongPlayer(
                    songs: _mediaItems,
                    initialIndex: index,
                  ),
                ),
              );
              print("Navigating to SongPlayer with path: $song");
            },
            child: ListTile(
              leading: const Icon(Icons.music_note),
              title: Text(
                song.title,
                style: const TextStyle(
                    color: Color.fromARGB(255, 145, 6, 99),
                    fontSize: 15,
                    fontWeight: FontWeight.bold),
              ),
              subtitle: Text(
                '${song.artist} - ${song.album}',
                style: const TextStyle(
                    color: Color.fromRGBO(198, 127, 5, 0.522),
                    fontSize: 12,
                    fontWeight: FontWeight.bold),
              ),
            ),
          );
        },
      ),
    );
  }
}
